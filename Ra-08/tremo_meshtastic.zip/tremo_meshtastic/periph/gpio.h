#ifndef _GPIO_H_
#define _GPIO_H_

#include "bsp.h"

void mygpio_init(void);

#endif
