#ifndef _UART_H_
#define _UART_H_

#include "bsp.h"

void myuart_init(uint32_t br);
void auxuart_init(uint32_t br);

#endif
