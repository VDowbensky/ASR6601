
#include "N79E81x.h"
#include "Typedef.h"
#include "Delay.h"
#include "Define.h"
#include "SPI.h"
#include "ssv7241.h"
#include <stdio.h>

/* default TX/RX Address and Address Width */
code const uint8 TX_ADDRESS[TX_ADR_WIDTH]={0xE3,0xE7,0xE7,0xE7,0xE7}; 
code const uint8 RX_ADDRESS[RX_ADR_WIDTH]={0xE3,0xE7,0xE7,0xE7,0xE7}; 

#define high_tx_pwr 1
#define simplified 0

/* memo */
uint8 DYN_ACKOn = 0;
uint8 ACK_PAYOn = 0;

#if simplified 
code const uint8 Initial_Reg_Array[] = {
0x1F, 0x01, 0x00,
0x1B, 0x04, 0xD0, 0xE1, 0xD3, 0x3D,
0x19, 0x04, 0x06, 0xAA, 0x62, 0xC3,
0x1F, 0x01, 0x01,
#if high_tx_pwr
0x18, 0x04, 0xBE, 0x6B, 0x96, 0x5B,
#else
0x18, 0x04, 0x5C, 0x14, 0x00, 0x5B,
#endif
0x19, 0x04, 0x77, 0x48, 0x9A, 0xC8,
0x1B, 0x04, 0x76, 0x87, 0xCA, 0x01,
0x1F, 0x01, 0x02,
0x1B, 0x04, 0xA0, 0x00, 0x18, 0xA0,
0x1F, 0x01, 0x04,
0x18, 0x04, 0x01, 0x00, 0xF0, 0x00,
0x1F, 0x01, 0x05,
0x18, 0x04, 0x84, 0x03, 0x2A, 0x03,
0x19, 0x04, 0x90, 0xBF, 0x00, 0x00,
0x1A, 0x04, 0xA0, 0x0F, 0x00, 0x00,
0x1F, 0x01, 0x00
};
#else
code const uint8 Initial_Reg_Array[] = {
0x1F, 0x01, 0x00,
0x1B, 0x04, 0xD0, 0xE1, 0xD3, 0x3D,
0x19, 0x04, 0x06, 0xAA, 0x62, 0xC3,
0x1F, 0x01, 0x01,
#if high_tx_pwr
0x18, 0x04, 0xBE, 0x6B, 0x96, 0x5B,
#else
0x18, 0x04, 0x5C, 0x14, 0x00, 0x5B,
#endif
0x19, 0x04, 0x77, 0x48, 0x9A, 0xC8,
0x1B, 0x04, 0x76, 0x87, 0xCA, 0x01,
0x1F, 0x01, 0x02,
0x1B, 0x04, 0xA0, 0x00, 0x18, 0xA0,
0x1F, 0x01, 0x04,
0x18, 0x04, 0x01, 0x00, 0xF0, 0x00,
0x1F, 0x01, 0x05,
0x18, 0x04, 0x84, 0x03, 0x2A, 0x03,
0x19, 0x04, 0x90, 0xBF, 0x00, 0x00,
0x1A, 0x04, 0xA0, 0x0F, 0x00, 0x00,
0x1F, 0x01, 0x08,
0x19, 0x01, 0x10,
0x18, 0x04, 0x00, 0xF8, 0xFF, 0x03,
0x19, 0x01, 0x9E,
0x19, 0x01, 0xBE,
0x18, 0x04, 0x07, 0x02, 0x04, 0x00,
0x19, 0x01, 0xDE,
0x19, 0x01, 0xFE,
0x18, 0x04, 0x00, 0x7C, 0x44, 0x00,
0x19, 0x01, 0x9F,
0x19, 0x01, 0xBF,
0x18, 0x04, 0x07, 0x02, 0x04, 0x00,
0x19, 0x01, 0xDF,
0x19, 0x01, 0xFF,
0x18, 0x04, 0x11, 0xFE, 0xFF, 0x00,
0x19, 0x01, 0x1E,
0x19, 0x01, 0x3E,
0x18, 0x04, 0x01, 0x8B, 0x30, 0x08,
0x19, 0x01, 0x5E,
0x19, 0x01, 0x7E,
0x18, 0x04, 0x10, 0xFF, 0x85, 0x00,
0x19, 0x01, 0x1F,
0x19, 0x01, 0x3F,
0x18, 0x04, 0x01, 0x8B, 0x30, 0x0C,
0x19, 0x01, 0x5F,
0x19, 0x01, 0x7F,
0x19, 0x01, 0x00,
0x1F, 0x01, 0x09,
0x18, 0x04, 0x00, 0x00, 0xF4, 0xF8,
0x1F, 0x01, 0x00
};
#endif


void SSV7241_InitSPI()
{
	//========================= USER DEFINE ==================
	P14=1;
	P01=0;
	//========================= USER DEFINE ==================
}

void SSV7241_Init()
{
	
	uint8 ret = 0;
	uint8 value; 
	
	/* Initial Register */
		uint32 i = 0, j = 0, k = 0;
		uint8 databuf[4];		
		uint32 array_length = sizeof(Initial_Reg_Array);
		
		while(i < array_length)
		{
			if(Initial_Reg_Array[i+1] == 0x01)
			{
				SSV7241_Write_Reg( W_REG | Initial_Reg_Array[i], Initial_Reg_Array[i+2]);
				i += 3;
			}
			else
			{ k=Initial_Reg_Array[i+1];
				for(j = 0; j < k; j++)
				{
					databuf[j] = Initial_Reg_Array[i+2+j];
				}

				SSV7241_Write_Buf( W_REG | Initial_Reg_Array[i], databuf, Initial_Reg_Array[i + 1]);
				i += 2+k;
			}
		}
	value = SSV7241_Read_Reg(CFG_TOP); 
	value |= (EN_CRC | CRC_2B);
	SSV7241_Write_Reg(W_REG | CFG_TOP, value);
		
	SSV7241_Write_Buf(W_REG | TX_ADDR,TX_ADDRESS,5);
	SSV7241_Write_Buf(W_REG | RX_ADDR_P0,RX_ADDRESS,5);		
	SSV7241_Write_Reg(W_REG | EN_AA,0x01);    
  SSV7241_Write_Reg(W_REG | EN_RXADDR,0x01);
  SSV7241_Write_Reg(W_REG | RF_CH,77);	
	SSV7241_Write_Reg(W_REG | RX_PW_P0,1);
	SSV7241_Enable_dynamic_payload(DPL_P0);
	SSV7241_Feature_ACK_PAY(1);	
	//SSV7241_Feature_DYN_ACK(1);		
		
	SSV7241_Write_Reg(W_REG | SETUP_RETR,0);
	SSV7241_Write_Reg(W_REG | SETUP_RETR,ARD_750us|ARC_2);	
			
	value = SSV7241_Read_Reg(SETUP_RF);
	value &= ~(RATE_2M|RATE_250K);
	value |= RATE_250K;
	value &= ~(PWR_LEVEL4);
	value |= PWR_LEVEL4;
	SSV7241_Write_Reg(W_REG | SETUP_RF, value); 	
		
	
}

uint8 SSV7241_CheckID(void)
{
	uint8 ret = 0;
	uint8 databuf[4];
	
	/* When power off, Chip ID can be read */
	SSV7241_PowerOff();
	/* When RSSI disable, Chip ID can be read */
	SSV7241_DisableRSSI();
	
	SSV7241_Read_Buf(0x18, databuf, 4); 
	
	if(databuf[0] == 0x41 && databuf[1] == 0x72)
		ret = 1;

	return ret;
}

void SSV7241_Write_Reg(uint8 reg,uint8 value)
{
	CS_Low;	   
  	
	SPI0_communication(reg);
	SPI0_communication(value);
	
	CS_High;   
}

uint8 SSV7241_Read_Reg(uint8 reg)
{
 	uint8 value;

	CS_Low;	    
  	
	SPI0_communication(reg);
	
	value = SPI0_communication(NOP);
	
	CS_High; 

	return value;
}

void SSV7241_Read_Buf(uint8 reg,uint8 *pBuf,uint8 len)
{
	uint8 i;
	
	CS_Low;      
  	
	SPI0_communication(reg);  	   
 	
	for(i = 0; i < len; i++)
		pBuf[i]=SPI0_communication(0XFF);
	
	CS_High; 
}

void SSV7241_Write_Buf(uint8 reg, uint8 *pBuf, uint8 len)
{
	uint8 i;
	
	CS_Low;
	
	SPI0_communication(reg);
	
  for(i = 0; i < len; i++)
		SPI0_communication(*pBuf++); 
	
	CS_High;	 
}

uint8 SSV7241_isRXReady(void)
{
	uint8 ret = 0, state;
	
	state = SSV7241_Read_Reg(STATUS);  
	if(state & RX_DR)
		ret = 1;
	
	return ret;
}

uint8 SSV7241_isTXReady(void)
{
	uint8 ret = 0, state;
	
	state = SSV7241_Read_Reg(STATUS);  
	if(state & TX_DS)
		ret |= 1;
	if(state & MAX_RT)
		ret |= 2;
	return ret;
}


uint8 SSV7241_isTXFULL(void)
{
	uint8 ret = 0, state;
		
	state = SSV7241_Read_Reg(STATUS_FIFO);
	if(state & TX_FULL)
		ret = 1;
	return ret;
}

uint8 SSV7241_isRXEMPTY(void)
{
	uint8 ret = 0, state;
	
	state = SSV7241_Read_Reg(STATUS_FIFO);
	if(state & RX_EMPTY)
		ret = 1;
	return ret;	
}

void SSV7241_ClearRX_DR(void)
{
	uint8 state;
		
	state = SSV7241_Read_Reg(STATUS);
	state |= RX_DR;
	SSV7241_Write_Reg(W_REG | STATUS, state);
}

void SSV7241_ClearTX_DS(void)
{
	uint8 state;
	
	state = SSV7241_Read_Reg(STATUS); 
	state |= TX_DS;	
	SSV7241_Write_Reg(W_REG | STATUS, state); 
	
}

void SSV7241_ClearMAX_RT(void)
{
	uint8 state;
	
	state = SSV7241_Read_Reg(STATUS); 
	state |= MAX_RT;	
	SSV7241_Write_Reg(W_REG | STATUS, state);
}

void SSV7241_FlushRX(void)
{
	SSV7241_Write_Reg(FLUSH_RX, NOP);
}

void SSV7241_FlushTX(void)
{
	SSV7241_Write_Reg(FLUSH_TX, NOP);
}

uint8 SSV7241_RxPacket(uint8 *rxbuf)
{
	uint8 ret = 0, len = 0;
	
	//Check and Receive Data
	//if(SSV7241_isRXReady())
	{
		len = SSV7241_Read_Reg(R_RX_PL_WID);
		
		SSV7241_Read_Buf(R_RX_PLOAD, rxbuf, len); 
		printf("  len:%d",len);
		//Clear RX_DR status
		SSV7241_ClearRX_DR();
		ret = len;
	}
	
	return ret;
}

uint8 SSV7241_RxAckPacket(uint8 *rxbuf)
{
	uint8 ret = 0, len = 0;

		len = SSV7241_Read_Reg(R_RX_PL_WID);
		SSV7241_Read_Buf(R_RX_PLOAD, rxbuf, len); 

		SSV7241_FlushRX();
		ret = len;

	return ret;
}



void SSV7241_TxPacket(uint8 *txbuf, uint8 len)
{ 
	uint8_t i=0;
	//Check Queue is full or not and Send packet
	SSV7241_FlushTX();
	SSV7241_ClearTX_DS();	
	//if(!SSV7241_isTXFULL())
	{	
		
		if(!DYN_ACKOn)
			SSV7241_Write_Buf(W_TX_PLOAD, txbuf, len);
		else
			SSV7241_Write_Buf(W_TX_PLOAD_NOACK, txbuf, len);
		
			CE_High;
			SYS_Delay_10us();
			do
			{
				i =SSV7241_isTXReady();
			}
			while(i==0);
			SSV7241_ClearTX_DS();	
			CE_Low;
	}
}


uint8_t SSV7241_TxPacket_ACK(uint8 *txbuf, uint8 len)
{ 
	
	uint8_t ret=0;
	//Check Queue is full or not and Send packet
	SSV7241_FlushRX();
	SSV7241_ClearRX_DR();
	SSV7241_FlushTX();
	SSV7241_ClearTX_DS();	
	//if(!SSV7241_isTXFULL())
	{	
		
		if(!DYN_ACKOn)
			SSV7241_Write_Buf(W_TX_PLOAD, txbuf, len);
		else
			SSV7241_Write_Buf(W_TX_PLOAD_NOACK, txbuf, len);
		
		CE_High;
    SYS_Delay_10us();
		do
		{
			ret =SSV7241_isTXReady();
		}
		while(ret==0);
		SSV7241_ClearTX_DS();	
    CE_Low;

	}
	return ret;
}

void SSV7241_TxACKPacket(uint8 *txbuf, uint8 len)
{ 
	//Check Queue is full or not and Send packet
	if(!SSV7241_isTXFULL())
	{	

		SSV7241_Write_Buf(W_ACK_PLOAD, txbuf, len);
 	
//		CE_High;
//    SYS_Delay_10us();
//    CE_Low;		
	}
}

void SSV7241_TxPacketWithoutAck(uint8 *txbuf, uint8 len)
{ 
	//Check Queue is full or not and Send packet
	
	if(!SSV7241_isTXFULL())
	{
  	
		if(DYN_ACKOn)
			SSV7241_Write_Buf(W_TX_PLOAD, txbuf, len);
		else
			SSV7241_Write_Buf(W_TX_PLOAD_NOACK, txbuf, len);
 	
	  CE_High;
    SYS_Delay_10us();
		while(SSV7241_isTXReady()==0);
		SSV7241_ClearTX_DS();	
		
    CE_Low;		
	}
}	

void SSV7241_RX_Mode(void)
{
	  	     
  uint8 value;
	
	value = SSV7241_Read_Reg(CFG_TOP); 
	value |= RX_ON;	
	SSV7241_Write_Reg(W_REG | CFG_TOP, value); 	
	CE_High;
}

void SSV7241_TX_Mode(void)
{
	uint8 value;
	
	value = SSV7241_Read_Reg(CFG_TOP); 
	value &= ~RX_ON;
	SSV7241_Write_Reg(W_REG | CFG_TOP, value); 
}

void SSV7241_PowerOn(void)
{
	uint8 value;
	uint8 databuf[4];
	
	value = SSV7241_Read_Reg(CFG_TOP); 
	value |= PWR_ON;	
	SSV7241_Write_Reg(W_REG | CFG_TOP, value); 
	
	/* refine RF */
	databuf[0] = 0x06;
	databuf[1] = 0xAA;
	databuf[2] = 0x62;
	databuf[3] = 0xC3;
	SSV7241_Write_Buf( W_REG | 0x19, databuf, 4);
}

void SSV7241_PowerOff(void)
{
	uint8 value;
	uint8 databuf[4];
	
	value = SSV7241_Read_Reg(CFG_TOP); 
	value &= ~PWR_ON;
	SSV7241_Write_Reg(W_REG | CFG_TOP, value); 	
	
	/* refine RF */
	databuf[0] = 0x06;
	databuf[1] = 0xAA;
	databuf[2] = 0x62;
	databuf[3] = 0x43;
	SSV7241_Write_Buf( W_REG | 0x19, databuf, 4);
}

void SSV7241_Feature_DYN_ACK(uint8 Dyn_ack)
{
	uint8 value;
	
	/* Dynamic Ack Setting */
	value = SSV7241_Read_Reg(FEATURE);
	
	if(Dyn_ack)
	{
		value |= EN_DYN_ACK;
		DYN_ACKOn = 1;
	}
	else
	{
		value &= ~EN_DYN_ACK;
		DYN_ACKOn = 0;
	}
	
	SSV7241_Write_Reg(W_REG | FEATURE, value); 	
}

void SSV7241_Feature_DPL(uint8 Dpl)
{
	uint8 value;
	
	/* Dynamic Ack Setting */
	value = SSV7241_Read_Reg(FEATURE);
	
	if(Dpl)
		value |= EN_DPL;
	else
		value &= ~EN_DPL;
	
	SSV7241_Write_Reg(W_REG | FEATURE, value); 	
}

void SSV7241_Feature_ACK_PAY(uint8 Ack_pay)
{
	uint8 value;
	
	/* Ack Payload Setting */
	value = SSV7241_Read_Reg(FEATURE);
	
	if(Ack_pay)
	{
		value |= EN_ACK_PAY;
		ACK_PAYOn = 1;
	}
	else
	{
		value &= ~EN_ACK_PAY;
		ACK_PAYOn = 0;
	}
	
	SSV7241_Write_Reg(W_REG | FEATURE, value); 	
}

void SSV7241_EnableRSSI(void)
{
	uint8 value;
	
	value = SSV7241_Read_Reg(RSSI);
	value |= EN_RSSI;
	
	SSV7241_Write_Reg(W_REG | RSSI, value); 	
}

void SSV7241_DisableRSSI(void)
{
	uint8 value;
	
	value = SSV7241_Read_Reg(RSSI);
	value &= ~EN_RSSI;
	
	SSV7241_Write_Reg(W_REG | RSSI, value); 	
}

void SSV7241_SetChannel(uint8 channel)
{
	
	SSV7241_Write_Reg(W_REG | RF_CH, channel); 
	
}


void SSV7241_Enable_dynamic_payload(uint8 dpl_px)
{
	uint8 value;
	
		SSV7241_Feature_DPL(1);
	  value = SSV7241_Read_Reg(DYNPD);
		value |= dpl_px;
	  SSV7241_Write_Reg(W_REG | DYNPD, value); 
}

uint8 SPI0_communication(uint8 SPI_byte)
{
				
	//========================= USER DEFINE ==================
		SPDR = SPI_byte;
    //Delay10us(1);                               
    while(!(SPSR & SET_BIT7));
		SPI_byte=SPDR ;
		clr_SPIF;
	//========================= USER DEFINE ==================

	return (SPI_byte);
} // END SPI_Transfer




//uint8 SPI0_communication(uint8 SPI_byte)
//{
//	uint8 SPI_count; // counter for SPI transaction
//	
//	//========================= USER DEFINE ==================
//	// need to define MOSI, MISO, SCK signal
//	
//	for (SPI_count = 8; SPI_count > 0; SPI_count--) // single byte SPI loop
//	{
//		MOSI = SPI_byte & 0x80; // put current outgoing bit on MOSI
//		SPI_byte = SPI_byte << 1; // shift next bit into MSB
//		SCK = 0x01; // set SCK high
//		SPI_byte |= MISO; // capture current bit on MISO
//		SCK = 0x00; // set SCK low
//	}
//	
//	//========================= USER DEFINE ==================

//	return (SPI_byte);
//} // END SPI_Transfer

