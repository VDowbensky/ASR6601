typedef enum
{
    E_CHANNEL0,
    E_CHANNEL1,
    E_CHANNEL2,
    E_CHANNEL3,
    E_CHANNEL4,
    E_CHANNEL5,
    E_CHANNEL6,
    E_CHANNEL7,
} E_ADCCNL_SEL;


//ADCCON0
#define set_ADCEX   ADCEX = 1;
#define set_ADCI    ADCI  = 1;
#define set_ADCS    ADCS  = 1;
#define set_AADR2   AADR2 = 1;
#define set_AADR1   AADR1 = 1;
#define set_AADR0   AADR0 = 1;

#define clr_ADCEX   ADCEX = 0;
#define clr_ADCI    ADCI  = 0;
#define clr_ADCS    ADCS  = 0;
#define clr_AADR2   AADR2 = 0;
#define clr_AADR1   AADR1 = 0;
#define clr_AADR0   AADR0 = 0;

//ADCCON1
#define set_ADCEN   ADCCON1 |= SET_BIT7;
#define set_RCCLK   ADCCON1 |= SET_BIT1;
#define set_ADC0SEL ADCCON1 |= SET_BIT0;

#define clr_ADCEN   ADCCON1 &= CLR_BIT7;
#define clr_RCCLK   ADCCON1 &= CLR_BIT1;
#define clr_ADC0SEL ADCCON1 &= CLR_BIT0;

void ADC_Iterrupt_Service_Routine(void);
void Enable_ADC_Interrupt(void);
void ADC_Channel_Sel(E_ADCCNL_SEL channel);
void Trigger_ADC_Convertion(void);
void ADC_Init(void);
void Set_ADC_Input_Mode(E_ADCCNL_SEL channel);
