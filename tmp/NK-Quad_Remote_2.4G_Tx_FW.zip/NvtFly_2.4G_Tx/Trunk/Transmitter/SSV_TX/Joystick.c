/*============================================================================*
 * O     O          __                   ______  __                           *
 *  \   /      /\  / /_      _    __    / /___/ / /_     _                    *
 *   [+]      /  \/ / \\    //__ / /__ / /____ / / \\   //                    *
 *  /   \    / /\  /   \\__// --/ /---/ /----// /   \\_//                     *
 * O     O  /_/  \/     \__/    \_\/ /_/     /_/ ____/_/                      *
 *                                                                            *
 *                                                                            *
 * Multi-Rotor controller firmware for Nuvoton Cortex M4 series               *
 *                                                                            *
 * Written by by T.L. Shen for Nuvoton Technology.                            *
 * tlshen@nuvoton.com/tzulan611126@gmail.com                                  *
 *                                                                            *
 *============================================================================*
 */
#define Uart_Port_Sel   0x00

#include "N79E81x.h"
#include "Typedef.h"
#include "Define.h"
#include "Common.h"
#include "Delay.h"
#include "ADC.h"
#include "Version.h"
#include "Flash.h"
#include "Joystick.h"
#include "SSV_TX.h"
#include <intrins.h>
#include <stdio.h>
#include <string.h>

#ifndef MODE3
/* USA*/
/* Button ADC
 [LB_CH]  |  [RB_CH]   |  GAPE_LB  |  GAPE_RB  
----------------------------------------------
 LR    0  |   RB  202  |   100     |   250
 LB  193  |   RR  315  |   300     |   350
 Y-  395  |   R+  405  |   500     |   500
 Y+  598  |   R-  605  |   700     |   700
 T-  805  |   P-  809  |   900     |   900
 T+ 1022  |   P+ 1022  |

*/
/* 
	[LB_CH]
	Bit:   0 |  1  |  2 |  3 |  4 |  5   
  Btn:  LR | LB  | Y- | Y+ | T- | T+ 
	[LR_CH]
	Bit:   0 |  1  |  2 |  3 |  4 |  5 
  Btn:  RB | RR  | R+ | R- | P- | P+  
*/
#define LR  0
#define LB  1
#define YM  2
#define YP  3
#define TM  4
#define TP  5

#define RB  0
#define RR  1
#define RP  2
#define RM  3
#define PM  4
#define PP  5
#else
/*Japan MODE
/* Button ADC
 [LB_CH]  |  [RB_CH]   |  GAPE_LB  |  GAPE_RB  
----------------------------------------------
 LR    0  |   RB  202  |   100     |   250
 LB  193  |   RR  315  |   300     |   350
 R-  395  |   Y+  405  |   500     |   500
 R+  598  |   Y-  605  |   700     |   700
 P-  805  |   T-  809  |   900     |   900
 P+ 1022  |   T+ 1022  |

*/
/*  
	[LB_CH]
	Bit:   0 |  1  |  2 |  3 |  4 |  5   
  Btn:  LR | LB  | R- | R+ | P- | P+ 
	[LR_CH]
	Bit:   0 |  1  |  2 |  3 |  4 |  5 
  Btn:  RB | RR  | Y+ | Y- | T- | T+  
*/

#define LR  0
#define LB  1
#define RM  2
#define RP  3
#define PM  4
#define PP  5

#define RB  0
#define RR  1
#define YP  2
#define YM  3
#define TM  4
#define TP  5
#endif

#define GAPE_NUM 	5
#define   JSCALE	2

code int16_t SWITCH_ALT[2] = {200, 800};
code int16_t SWITCH_MOD[3] = {160, 500, 820};
pdata uint8_t SWITCH = 0;
code uint16_t GAPE_LB[GAPE_NUM] = {100,300,500,700,900};
code uint16_t GAPE_RB[GAPE_NUM] = {250,350,500,700,900};
pdata uint8_t LBState = LR, LBStateOld = LR, LBPressed = LR;
pdata uint8_t RBState = RR, RBStateOld = RR, RBPressed = RR;
BIT JoyUpdate=0;
BIT MatchAddressUpdate=0;
BIT CheckFlashUpdate()
{
	return (JoyUpdate|MatchAddressUpdate);
}
void ClearFlashUpdate()
{
	JoyUpdate = 0;
	MatchAddressUpdate = 0;
}
int16_t GetSwitchValue(UINT8 Switch)
{
	if(Switch)
		return SWITCH_MOD[(SWITCH&0xf)%3];
	else
		return SWITCH_ALT[(SWITCH>>4)%2];
}
uint8_t CheckGape(UINT16 ADC, uint16_t* GAPE)
{
	int8_t i;
	for(i=0; i<GAPE_NUM; i++) {
		if((ADC)<GAPE[i])
			return i;
	}
	return i;
}
int8_t INC(int8_t a)
{
	int16_t check;
	check = a + JSCALE;
	if(check<=127) {
		JoyUpdate=1;
		return (int8_t)check;
	}
	else
		return a;
}
int8_t DEC(int8_t a)
{
	int16_t check;
	check = a - JSCALE;
	if(check>=-128) {
		JoyUpdate=1;
		return (int8_t)check;
	}
	else
		return a;
}
void UpdateSwitch(uint8_t Btn)
{
	if(GetTickCount()<500)
		return;
#ifdef MODE3
	//Btn=(Btn+1)&1;
#endif
	switch(Btn) {
		case LB:
			if(((SWITCH>>4)&0xf)==0xf)
				SWITCH&=0xf;
			else
				SWITCH+=16;
			break;
		case RB:
			if((SWITCH&0xf)==0xe)
				SWITCH&=0xf0;
			else
			SWITCH++;
			break;
		default:
			break;
	}
	//DEBUG_PRINT(" 0x%x ", (uint16_t)SWITCH);
}
void CheckBtn(UINT16* ChannelADC)
{
	int8_t* JoyS;
	JoyS = GetJoyState();
	LBState = CheckGape(ChannelADC[LB_CH],GAPE_LB);
	RBState = CheckGape(ChannelADC[RB_CH],GAPE_RB);
	//DEBUG_PRINT("%d %d\n",(UINT16)LBStateOld,(UINT16)LBState);
	if(LBStateOld!=LR) {
		if(LBState==LR) {
			if(LBPressed!=LBStateOld)
				LBPressed=LBStateOld;
		
			switch(LBPressed) {
				case LB:
					UpdateSwitch(LB);
					break;
#ifndef MODE3
				case YM:
					JoyS[YAW]=DEC(JoyS[YAW]);
					break;
				case YP:
					JoyS[YAW]=INC(JoyS[YAW]);
					break;
				case TM:
					JoyS[THR]=DEC(JoyS[THR]);
					break;
				case TP:
					JoyS[THR]=INC(JoyS[THR]);
					break;
#else	
				case RP:
					JoyS[ROLL]=INC(JoyS[ROLL]);
					break;
				case RM:
					JoyS[ROLL]=DEC(JoyS[ROLL]);
					break;
				case PM:
					JoyS[PITCH]=DEC(JoyS[PITCH]);
					break;
				case PP:
					JoyS[PITCH]=INC(JoyS[PITCH]);
					break;
#endif
				default:	
					break;
			}
		}
	}
	
	if(RBStateOld!=RR) {
		if(RBState==RR) {
			if(RBPressed!=RBStateOld)
				RBPressed=RBStateOld;
	
			switch(RBPressed) {
				case RB:
					UpdateSwitch(RB);
					break;
#ifndef MODE3
				case RP:
					JoyS[ROLL]=INC(JoyS[ROLL]);
					break;
				case RM:
					JoyS[ROLL]=DEC(JoyS[ROLL]);
					break;
				case PM:
					JoyS[PITCH]=DEC(JoyS[PITCH]);
					break;
				case PP:
					JoyS[PITCH]=INC(JoyS[PITCH]);
					break;
#else
				case YM:
					JoyS[YAW]=DEC(JoyS[YAW]);
					break;
				case YP:
					JoyS[YAW]=INC(JoyS[YAW]);
					break;
				case TM:
					JoyS[THR]=DEC(JoyS[THR]);
					break;
				case TP:
					JoyS[THR]=INC(JoyS[THR]);
					break;
#endif
				default:
					break;
			}
		}
	}
	
	LBStateOld = LBState;
	RBStateOld = RBState;
}
//-----------------------------------------------------------------------------------------------------------
void Enable_ADC_Interrupt(void)
{ 
	EADC = 1;
	EA = 1;
}
//-----------------------------------------------------------------------------------------------------------
void ADC_Channel_Sel(E_ADCCNL_SEL channel)
{
	switch (channel)
	{
		case E_CHANNEL0:                                // P0.1 (default)
			clr_AADR2;
			clr_AADR1;
			clr_AADR0;
			break;
#ifndef V10
		case E_CHANNEL1:                                // P0.2
			clr_AADR2;
			clr_AADR1;
			set_AADR0;
			break;
		case E_CHANNEL2:                                // P0.3
			clr_AADR2;
			set_AADR1;
			clr_AADR0;
			break;
		case E_CHANNEL3:                                // P0.4
			clr_AADR2;
			set_AADR1;
			set_AADR0;
			break;
		case E_CHANNEL4:                                // P0.5
			set_AADR2;
			clr_AADR1;
			clr_AADR0;
			break;
#else
			case E_CHANNEL4:                                // P0.2
				clr_AADR2;
				clr_AADR1;
				set_AADR0;
				break;
			case E_CHANNEL3:                                // P0.3
				clr_AADR2;
				set_AADR1;
				clr_AADR0;
				break;
			case E_CHANNEL2:                                // P0.4
				clr_AADR2;
				set_AADR1;
				set_AADR0;
				break;
			case E_CHANNEL1:                                // P0.5
				set_AADR2;
				clr_AADR1;
				clr_AADR0;
				break;
#endif
		case E_CHANNEL5:                                // P0.6
			set_AADR2;
			clr_AADR1;
			set_AADR0;
			break;
		case E_CHANNEL6:                                // P0.7
			set_AADR2;
			set_AADR1;
			clr_AADR0;
			break;
		case E_CHANNEL7:                                // P2.6
			set_AADR2;
			set_AADR1;
			set_AADR0;
			break;
	}
}
//-----------------------------------------------------------------------------------------------------------
void Set_ADC_Input_Mode(E_ADCCNL_SEL channel)
{
	switch (channel)
	{
		case E_CHANNEL0:                                // ADC0(P0.1) is input-only mode
			P0DIDS |= SET_BIT1;                         // Disable digital function for P0.1
		P0M1 = SET_BIT1;
			P0M2 = 0x00;
			break;
		case E_CHANNEL1:                                // ADC1(P0.2) is input-only mode
			P0DIDS |= SET_BIT2;                         // Disable digital function for P0.2
			P0M1 = SET_BIT2;
			P0M2 = 0x00;
			break;
		case E_CHANNEL2:                                // ADC2(P0.3) is input-only mode
			P0DIDS |= SET_BIT3;                         // Disable digital function for P0.3
			P0M1 = SET_BIT3;
			P0M2 = 0x00;
			break;
		case E_CHANNEL3:                                // ADC3(P0.4) is input-only mode
			P0DIDS |= SET_BIT4;                         // Disable digital function for P0.4
			P0M1 = SET_BIT4;
			P0M2 = 0x00;
			break;
		case E_CHANNEL4:                                // ADC4(P0.5) is input-only mode
			P0DIDS |= SET_BIT5;                         // Disable digital function for P0.5
			P0M1 = SET_BIT5;
			P0M2 = 0x00;
			break;
		case E_CHANNEL5:                                // ADC5(P0.6) is input-only mode
			P0DIDS |= SET_BIT6;                         // Disable digital function for P0.6
			P0M1 = SET_BIT6;
			P0M2 = 0x00;
			break;
		case E_CHANNEL6:                                // ADC6(P0.7) is input-only mode
			P0DIDS |= SET_BIT7;                         // Disable digital function for P0.7
			P0M1 = SET_BIT7;
			P0M2 = 0x00;
			break;
		case E_CHANNEL7:                                // ADC7(P2.6) is input-only mode(28 pin only)
			AUXR1 |= SET_BIT3;                          // Disable digital function for P2.6
			P2M1 = SET_BIT6;
			P2M2 = 0x00;
			break;
	}
}
//-----------------------------------------------------------------------------------------------------------
void Trigger_ADC_Convertion(void)
{
    clr_ADCI;                                           // Clear ADC flag (ADCI=0)
    set_ADCS;                                           // ADC run (ADCS = 1)
    PCON |= SET_BIT0;                                   // Enter idle mode
}
//-----------------------------------------------------------------------------------------------------------
void ADC_Init(void)
{
    Set_ADC_Input_Mode(E_CHANNEL0);                     // Set ADC0 (P0.1 default) is input only mode
		Set_ADC_Input_Mode(E_CHANNEL1);
		Set_ADC_Input_Mode(E_CHANNEL2);
		Set_ADC_Input_Mode(E_CHANNEL3);
		Set_ADC_Input_Mode(E_CHANNEL4);
		Set_ADC_Input_Mode(E_CHANNEL5);
	

    Enable_ADC_Interrupt();

    set_ADCEN;                                          // Enable ADC Function
}
//-----------------------------------------------------------------------------------------------------------
void ADC_ISR(void) interrupt 11                         // Vector @  0x5B
{
    clr_ADCI;                                           // Clear ADC flag (ADCI = 0)
    clr_ADCS;                                           // ADC stop (ADCS = 0)
}
//-----------------------------------------------------------------------------------------------------------






