#define clr_WDTF  \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDTF = 0;     \
    EA = EA_Save_bit;
#define clr_BOF   \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    PMCR &= CLR_BIT3;\
    EA = EA_Save_bit;
#define set_WDTF  \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDTF = 1;     \
    EA = EA_Save_bit;
#define set_BOF   \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    PMCR |= SET_BIT3;\
    EA = EA_Save_bit;

#define clr_KBIF0   KBIF    &= CLR_BIT0;
#define clr_CAPF0   CAPCON0 &= CLR_BIT0;
#define clr_BKF     PWMCON2 &= CLR_BIT0;
#define clr_SPIF    SPSR    &= CLR_BIT7;
#define clr_ADCI    ADCCON0 &= CLR_BIT4;
#define clr_SI      SI = 0;
#define clr_TF2     TF2  = 0;
#define clr_RI      RI   = 0;
#define clr_TF1     TF1  = 0;
#define clr_IE1     IE1  = 0;
#define clr_TF0     TF0  = 0;
#define clr_IE0     IE0  = 0;

#define set_KBIF0   KBIF    |= SET_BIT0;
#define set_CAPF0   CAPCON0 |= SET_BIT0;
#define set_BKF     PWMCON2 |= SET_BIT0;
#define set_SPIF    SPSR    |= SET_BIT7;
#define set_ADCI    ADCCON0 |= SET_BIT4;
#define set_SI      SI = 1;
#define set_TF2     TF2  = 1;
#define set_RI      RI   = 1;
#define set_TF1     TF1  = 1;
#define set_IE1     IE1  = 1;
#define set_TF0     TF0  = 1;
#define set_IE0     IE0  = 1;
