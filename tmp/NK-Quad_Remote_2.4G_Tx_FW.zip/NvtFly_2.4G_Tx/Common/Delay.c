/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright(c) 2014 Nuvoton Technology Corp. All rights reserved.                                         */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

//***********************************************************************************************************
//  Nuvoton Technology Corp.
//  Date: 23/Jan/2014
//  E-Mail: MicroC-8bit@nuvoton.com
//***********************************************************************************************************

#include <stdio.h>
#include "N79E81x.h"
#include "Typedef.h"
#include "Define.h"
#include "Common.h"
#include "Delay.h"

#ifdef FOSC_110592
    #define VALUE_10us    65536-9      //27*12/11.0592 = 10 us
    #define VALUE_1ms     65536-923    //2769*12/11.0592 = 1 ms
#endif
#ifdef FOSC_184320
    #define VALUE_10us    65536-15      //15*12/18.432 = 10 us
    #define VALUE_1ms     65536-1536    //1536*12/18.432 = 1 ms
#endif
#ifdef FOSC_221184
    #define VALUE_10us    65536-18      //18*12/22.1184 = 10 us
    #define VALUE_1ms     65536-1843    //1843*12/22.1184 = 1 ms
#endif
#ifdef FOSC_368640
    #define VALUE_10us    65536-93      //93*12/36.864 = 10 us
    #define VALUE_1ms     65536-3072    //3072*12/36.864 = 1 ms
#endif
//-------------------------------------------------------------------------

void Delay1us(UINT16 u16CNT)
{
	while(u16CNT--);
}



void Delay10us(UINT16 u16CNT)
{
    TR0 = 1;
    while (u16CNT != 0)
    {
        TL0 = LOBYTE(VALUE_10us);
        TH0 = HIBYTE(VALUE_10us);
        while (TF0 != 1);
        TF0 = 0;
        u16CNT --;
    }
    TR0 = 0;
}
//------------------------------------------------------------------------------
void Delay1ms(UINT32 u32CNT)
{
    TR0 = 1;
    while (u32CNT != 0)
    {
        TL0 = LOBYTE(VALUE_1ms);
        TH0 = HIBYTE(VALUE_1ms);
        while (TF0 != 1);
        TF0 = 0;
        u32CNT --;
    }
    TR0 = 0;
}

void Delay8msInit(void)//921600*0.008=7372.8
{
		 TR0 = 1; 
     TL0 = LOBYTE((65536-7372));
     TH0 = HIBYTE((65536-7372));
		//while (TF0 != 1);
     //TF0 = 0;
		 //TR0 = 0;
}

void WaitDelay(void)
{
		while (TF0 != 1);
     TF0 = 0;
		 TR0 = 0;
}