/*============================================================================*
 * O     O          __                   ______  __                           *
 *  \   /      /\  / /_      _    __    / /___/ / /_     _                    *
 *   [+]      /  \/ / \\    //__ / /__ / /____ / / \\   //                    *
 *  /   \    / /\  /   \\__// --/ /---/ /----// /   \\_//                     *
 * O     O  /_/  \/     \__/    \_\/ /_/     /_/ ____/_/                      *
 *                                                                            *
 *                                                                            *
 * Multi-Rotor controller firmware for Nuvoton Cortex M4 series               *
 *                                                                            *
 * Written by K.H Hsu for Nuvoton Technology.                                 *
 *                                                                            *
 *============================================================================*
 */
#ifndef __BUZZER_H__
#define __BUZZER_H__
void Beep(uint8_t DO, uint8_t RE, uint8_t ME,uint8_t TD ,uint8_t TR, uint8_t TM);
void SSVLinkBeep(void);
void PowerOnBeep(void);
#endif

