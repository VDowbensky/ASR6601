/*============================================================================*
 * O     O          __                   ______  __                           *
 *  \   /      /\  / /_      _    __    / /___/ / /_     _                    *
 *   [+]      /  \/ / \\    //__ / /__ / /____ / / \\   //                    *
 *  /   \    / /\  /   \\__// --/ /---/ /----// /   \\_//                     *
 * O     O  /_/  \/     \__/    \_\/ /_/     /_/ ____/_/                      *
 *                                                                            *
 *                                                                            *
 * Multi-Rotor controller firmware for Nuvoton Cortex M4 series               *
 *                                                                            *
 * Written by by T.L. Shen for Nuvoton Technology.                            *
 * tlshen@nuvoton.com/tzulan611126@gmail.com                                  *
 *                                                                            *
 *============================================================================*
*/
/*
Flash used 1 byte for Japan/USA type selection and 4 bytes for joystick control
Byte0: Japan/USA switch
Byte1: Throttle adj
Byte2: Yaw adj
Byte3: Roll adj
Byte4: Pitch adj
*/
#include "N79E81x.h"
#include "Typedef.h"
#include "Define.h"
#include "Common.h"
#include "Delay.h"
#include "Version.h"
#include "Joystick.h"
#include "Flash.h"
#include <intrins.h>
#include <stdio.h>
#include <string.h>
#define FLASH_BASE 0x3000
#define JOY_DATA_SZ  5
#define MATCH_ADDRESS_SZ  6
#define PAGE_SZ    128

#define JAPAN_CTL  22
#define USA_CTL  	 11

#define FLASH_VALID           0x77

#define ERASE_ALL_DATA        0x22
#define FLASH_READ_DATA       0x00
#define BYTE_PROGRAM_DATA     0x21

#define ERASE_ALL_CONFIG      0xE2
#define FLASH_READ_CONFIG     0xC0
#define BYTE_PROGRAM_CONFIG   0xE1

bit EA_Save_bit;
pdata int8_t JoyState[JOY_DATA_SZ];
pdata uint8_t MATCH_ADDRESS[MATCH_ADDRESS_SZ];
int8_t* GetJoyState()
{
	return JoyState;
}
uint8_t* GetFlashMatchAddress(void)
{
	return &MATCH_ADDRESS[0];
}
//-----------------------------------------------------------------------------------------------------------
void Clear_BOF(void)
{
	EA_Save_bit = EA;
	EA = 0;
	TA = 0xAA;
	TA = 0x55;
	PMCR &= CLR_BIT3;
	EA = EA_Save_bit;
}
//-----------------------------------------------------------------------------------------------------------
void Enable_ISP_Mode(void)
{
	/* Enable ISP  */
	EA_Save_bit = EA;
	EA = 0;
	TA = 0xAA;
	TA = 0x55;
	CHPCON |= 0x01;
	EA = EA_Save_bit;
}
//-----------------------------------------------------------------------------------------------------------
void Disable_ISP_Mode(void)
{
	/* Disable ISP */
	EA_Save_bit = EA;
	EA = 0;
	TA = 0xAA;
	TA = 0x55;
	CHPCON &= 0xFE;
	EA = EA_Save_bit;
}
//-----------------------------------------------------------------------------------------------------------
void Trigger_ISP(void)
{
	EA_Save_bit = EA;
	EA = 0;
	EA = 0;
	TA = 0xAA;
	TA = 0x55;
	ISPTRG |= 0x01;
	EA = EA_Save_bit;
}
//-----------------------------------------------------------------------------------------------------------
void Erase_Page0(void)
{
	Enable_ISP_Mode();
	ISPCN = ERASE_ALL_DATA;
	//Page Size = 128Byte
	//Data Flash from 0x3000 ~ 0x3FFF (4K bytes)
	ISPAL = LOBYTE(FLASH_BASE);               // 96*128=12288=0x3000,128*128=16384=0x4000
	ISPAH = HIBYTE(FLASH_BASE);               // 96*128=12288=0x3000,128*128=16384=0x4000
	Trigger_ISP();
	
	Disable_ISP_Mode();
}
void InitJoyState(void)
{
	UINT8 u8Count;
	JoyState[0] = USA_CTL;
	for(u8Count=1;u8Count<JOY_DATA_SZ;u8Count++)
		JoyState[u8Count] = 1;
}
void SetupMatchAddress(UINT8* Address,UINT8 Rand)
{
	UINT8 u8Count;

	for(u8Count=1;u8Count<MATCH_ADDRESS_SZ;u8Count++)
		MATCH_ADDRESS[u8Count] = Address[u8Count-1] + Rand;
}
void SetMatchAddressValid()
{
	MATCH_ADDRESS[0] = 0x77;
}
void UpdateFlash(void)
{
	UINT8 u8Count;

	Enable_ISP_Mode();
	ISPAL = FLASH_BASE&0xff;
	ISPAH = FLASH_BASE>>8;
	
	ISPCN = BYTE_PROGRAM_DATA;
		
	for(u8Count=0;u8Count<JOY_DATA_SZ;u8Count++) {
		ISPFD = JoyState[u8Count];
		Trigger_ISP();
		ISPAL++;
	}

	for(u8Count=0;u8Count<MATCH_ADDRESS_SZ;u8Count++) {
		ISPFD = MATCH_ADDRESS[u8Count];
		Trigger_ISP();
		ISPAL++;
	}
	/*DEBUG_PRINT("Flash Update Match Address:%x %x %x %x %x %x\n",(uint16_t)MATCH_ADDRESS[0],(uint16_t)MATCH_ADDRESS[1],
						(uint16_t)MATCH_ADDRESS[2],(uint16_t)MATCH_ADDRESS[3],(uint16_t)MATCH_ADDRESS[4],(uint16_t)MATCH_ADDRESS[5]);*/
	Disable_ISP_Mode();
}
void ReadFlash(void)
{
	UINT8 u8Count;

	Enable_ISP_Mode();
	ISPAL = FLASH_BASE&0xff;
	ISPAH = FLASH_BASE>>8;
	ISPCN = FLASH_READ_DATA;

	for(u8Count=0;u8Count<JOY_DATA_SZ;u8Count++) {
		Trigger_ISP();
		JoyState[u8Count] = ISPFD;
	
		ISPAL++;
	}
	for(u8Count=0;u8Count<MATCH_ADDRESS_SZ;u8Count++) {
		Trigger_ISP();
		MATCH_ADDRESS[u8Count] = ISPFD; 
		ISPAL++;
	}
	/*DEBUG_PRINT("Flash Read Match Address:%x %x %x %x %x %x\n",(uint16_t)MATCH_ADDRESS[0],(uint16_t)MATCH_ADDRESS[1],
						(uint16_t)MATCH_ADDRESS[2],(uint16_t)MATCH_ADDRESS[3],(uint16_t)MATCH_ADDRESS[4],(uint16_t)MATCH_ADDRESS[5]);*/

	Disable_ISP_Mode();
}
void CheckFlash(void)
{
	ReadFlash();

	if((UINT8)JoyState[JPN_USA]==0xff) {
		DEBUG_PRINT ("\nSetup Flash.");
		InitJoyState();
		UpdateFlash();
	}
	else if(((UINT8)JoyState[JPN_USA]==JAPAN_CTL)||((UINT8)JoyState[JPN_USA]==USA_CTL)) {
		//UINT8 u8Count;
		DEBUG_PRINT ("\nFlash OK:");
		/*for(u8Count=0;u8Count<JOY_DATA_SZ;u8Count++)
			DEBUG_PRINT("%d",(int16_t)JoyState[u8Count]);*/
		DEBUG_PRINT ("\n");
	}
	else {
		DEBUG_PRINT ("\nFlash Error.\n");
		Erase_Page0();
	}
}
//-----------------------------------------------------------------------------------------------------------
void FlashInit(void)
{
	Clear_BOF();
	TA = 0xAA;                          //Unlock SHBDA register
	TA = 0x55;
	SHBDA = 0x30;                       //Use SHBDA to determine APROM size and Data Flash
		
	CheckFlash();
}
//-----------------------------------------------------------------------------------------------------------
