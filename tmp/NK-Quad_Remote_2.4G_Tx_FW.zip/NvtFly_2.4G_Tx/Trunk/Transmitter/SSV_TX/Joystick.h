/*============================================================================*
 * O     O          __                   ______  __                           *
 *  \   /      /\  / /_      _    __    / /___/ / /_     _                    *
 *   [+]      /  \/ / \\    //__ / /__ / /____ / / \\   //                    *
 *  /   \    / /\  /   \\__// --/ /---/ /----// /   \\_//                     *
 * O     O  /_/  \/     \__/    \_\/ /_/     /_/ ____/_/                      *
 *                                                                            *
 *                                                                            *
 * Multi-Rotor controller firmware for Nuvoton Cortex M4 series               *
 *                                                                            *
 * Written by by T.L. Shen for Nuvoton Technology.                            *
 * tlshen@nuvoton.com/tzulan611126@gmail.com                                  *
 *                                                                            *
 *============================================================================*
 */
#ifndef __JOYSTICK_H__
#define __JOYSTICK_H__
#define CHANNEL_NUM 6

#ifndef MODE3
#define RB_CH       0
#define PITCH_CH    1
#define	ROLL_CH     2
#define YAW_CH      3
#define THR_CH      4
#define LB_CH       5
#else
#define RB_CH       0
#define PITCH_CH    4
#define	ROLL_CH     3
#define YAW_CH      2
#define THR_CH      1
#define LB_CH       5
#endif

#define ALT_SWITCH  0 
#define MOD_SWITCH  1

#define THR_LOW_BOUND 10
void ADC_Init(void);
void Trigger_ADC_Convertion(void);
void ProcessADC(void);
void CheckBtn(UINT16* ChannelADC);
BIT CheckFlashUpdate(void);
void ClearFlashUpdate(void);
int16_t GetSwitchValue(UINT8 Switch);
#endif

