void  InitialUART0_Timer1(UINT32 u32Baudrate);
void  Send_Data_To_PC (UINT8 c);
UINT8 Receive_Data_From_PC(void);
