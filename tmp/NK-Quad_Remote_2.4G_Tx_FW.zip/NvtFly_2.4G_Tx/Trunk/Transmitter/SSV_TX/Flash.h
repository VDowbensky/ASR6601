/*============================================================================*
 * O     O          __                   ______  __                           *
 *  \   /      /\  / /_      _    __    / /___/ / /_     _                    *
 *   [+]      /  \/ / \\    //__ / /__ / /____ / / \\   //                    *
 *  /   \    / /\  /   \\__// --/ /---/ /----// /   \\_//                     *
 * O     O  /_/  \/     \__/    \_\/ /_/     /_/ ____/_/                      *
 *                                                                            *
 *                                                                            *
 * Multi-Rotor controller firmware for Nuvoton Cortex M4 series               *
 *                                                                            *
 * Written by by T.L. Shen for Nuvoton Technology.                            *
 * tlshen@nuvoton.com/tzulan611126@gmail.com                                  *
 *                                                                            *
 *============================================================================*
 */
#ifndef __FLASH_H__
#define __FLASH_H__
#define JPN_USA    0
#define THR			   1
#define YAW			   2
#define ROLL			 3
#define PITCH		   4
#define MATCH_ADDRESS_EXIST 0
void FlashInit(void);
int8_t* GetJoyState(void);
uint8_t* GetFlashMatchAddress(void);
void SetupMatchAddress(UINT8* Address, uint8_t Rand);
void SetMatchAddressValid(void);
void UpdateFlash(void);
void Erase_Page0(void);
#endif

