/*============================================================================*
 * O     O          __                   ______  __                           *
 *  \   /      /\  / /_      _    __    / /___/ / /_     _                    *
 *   [+]      /  \/ / \\    //__ / /__ / /____ / / \\   //                    *
 *  /   \    / /\  /   \\__// --/ /---/ /----// /   \\_//                     *
 * O     O  /_/  \/     \__/    \_\/ /_/     /_/ ____/_/                      *
 *                                                                            *
 *                                                                            *
 * Multi-Rotor controller firmware for Nuvoton Cortex M4 series               *
 *                                                                            *
 * Written by by T.L. Shen for Nuvoton Technology.                            *
 * tlshen@nuvoton.com/tzulan611126@gmail.com                                  *
 *                                                                            *
 *============================================================================*
 */
#include "Typedef.h"
#include "N79E81x.h"
#include "SSV_TX.h"
#define LED_ARM         0
#define LED_MAG         1
#define LED_HEAD_FREE   2
#define LED_ALTHOLD     3
#define LED_LOW_BAT     4
#define LED_LOW_RSSI    5
#define LED_FLY_MODE    6
#define LED_ARM_PIN     P11
#define LED_MODE_PIN    P31
#define LED_FLYMODE_PIN P10
#define LED_HEADFREE_PIN P10
#define BUZZER_PIN      P07
#define ON               0
#define OFF              1
#define LED_STATE_TOGGLE 0
#define LED_STATE_ON     1
#define LED_STATE_OFF    2
bit SLedArm     = 0;
bit SLedMode    = 0;
bit SLedPower   = 1;
bit SLedFlyMode = 0;
bit SLedHeadfreeMode = 0;
pdata uint8_t Ack;
pdata uint8_t BuzzerCount = 0;

void Sled_arm_on()
{
	LED_ARM_PIN = ON;
	if((Ack&(1<<LED_ARM))==0) /* Copter arm led off */
		SLedArm = 0;
	
}
void Sled_arm_off()
{
	LED_ARM_PIN = OFF;

	if(GetTickCount()<500)    /* Power on in 2 second */
		SLedArm = 1;
	else if(Ack&(1<<LED_ARM)) /* Copter arm led on */
		SLedArm = 1;

}
void Sled_mode_on()
{
	LED_MODE_PIN = ON;

	if((Ack&(1<<LED_ALTHOLD))==0)
		SLedMode = 0;
}
void Sled_mode_off()
{
	LED_MODE_PIN = OFF;

	if(Ack&(1<<LED_ALTHOLD))
		SLedMode = 1;
}

void Sled_power_on()
{
	BuzzerCount++;
	if((BuzzerCount%3)==1)
         BUZZER_PIN = 1;

	if(Ack&(1<<LED_LOW_BAT))
		SLedPower = 0;
}
void Sled_power_off()
{
	BUZZER_PIN = 0;

	SLedPower = 1;
}
void Sled_flymode_on()
{
	LED_FLYMODE_PIN = ON;

	if((Ack&(1<<LED_FLY_MODE))==0)
		SLedFlyMode = 0;
}
void Sled_flymode_off()
{
	LED_FLYMODE_PIN = OFF;
	
	if(Ack&(1<<LED_FLY_MODE))
		SLedFlyMode = 1;
}
void Sled_headfree_on()
{
	LED_HEADFREE_PIN = ON;

	if((Ack&(1<<LED_HEAD_FREE))==0)
		SLedHeadfreeMode = 0;
}
void Sled_headfree_off()
{
	LED_HEADFREE_PIN = OFF;
	
	if(Ack&(1<<LED_HEAD_FREE))
		SLedHeadfreeMode = 1;
}
void UpdateState()
{
	Ack = GetAckData();
	if(SLedArm)
		Sled_arm_on();
	else
		Sled_arm_off();
	
	if(SLedMode)
		Sled_mode_on();
	else
		Sled_mode_off();
	
	if(SLedPower)
		Sled_power_on();
	else
		Sled_power_off();
	
	if(SLedFlyMode)
		Sled_flymode_on();
	else
		Sled_flymode_off();
	
	if(SLedHeadfreeMode)
		Sled_headfree_on();
	else
		Sled_headfree_off();
}
