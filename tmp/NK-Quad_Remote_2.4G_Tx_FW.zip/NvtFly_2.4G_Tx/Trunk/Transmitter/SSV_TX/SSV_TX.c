/*============================================================================*
 * O     O          __                   ______  __                           *
 *  \   /      /\  / /_      _    __    / /___/ / /_     _                    *
 *   [+]      /  \/ / \\    //__ / /__ / /____ / / \\   //                    *
 *  /   \    / /\  /   \\__// --/ /---/ /----// /   \\_//                     *
 * O     O  /_/  \/     \__/    \_\/ /_/     /_/ ____/_/                      *
 *                                                                            *
 *                                                                            *
 * Multi-Rotor controller firmware for Nuvoton Cortex M4 series               *
 *                                                                            *
 * Written by by T.L. Shen for Nuvoton Technology.                            *
 * tlshen@nuvoton.com/tzulan611126@gmail.com                                  *
 *                                                                            *
 *============================================================================*
*/
#define Uart_Port_Sel   0x00
#define SPI_Pin_Sel     0x00

#include "N79E81x.h"
#include "Typedef.h"
#include "Define.h"
#include "Common.h"
#include "Delay.h"
#include "SPI.h"
#include <stdio.h>
#include "ssv7241.h"
#include "Joystick.h"
#include "ADC.h"
#include "Flash.h"
#include "State.h"
#include "Buzzer.h"

#if (SPI_Pin_Sel == 0x00)
    #define SS              P14
#else
    #define SS              P24
#endif

#define HAND_MODE(a)  a

void SPI_Initial(void);

BIT SSVtimeUp = 0;
BIT ADCtimeUp = 0;
BIT FLASHtimeUp = 0;
BIT StatetimeUp = 0;
pdata uint32_t tickCounter = 0;
pdata UINT16 u16ADC[CHANNEL_NUM];
pdata int16_t SW_ALT;
pdata int16_t SW_MOD;
pdata uint8_t TxBUF[TxNUM];

//-----------------------------------------------------------------------------------------------------------
uint32_t GetTickCount()
{
	return tickCounter;
}
BIT GetSSVtimeUp()
{
	return SSVtimeUp;
}
void SetSSVtimeUp(BIT timeup)
{
	SSVtimeUp = timeup;
}
void ADC2TxBuffer()
{
	TxBUF[0] = u16ADC[THR_CH]>>2;
	TxBUF[1] = u16ADC[ROLL_CH]>>2;
	TxBUF[2] = u16ADC[PITCH_CH]>>2;
	TxBUF[3] = u16ADC[YAW_CH]>>2;
	TxBUF[4] = ((u16ADC[THR_CH]&3)<<6)|((u16ADC[ROLL_CH]&3)<<4)|((u16ADC[PITCH_CH]&3)<<2)|((u16ADC[YAW_CH]&3));
	TxBUF[5] = SW_ALT>>2;
	TxBUF[6] = SW_MOD>>2;
	TxBUF[7] = ((SW_ALT&3)<<2)|((SW_MOD&3));
}
void ProcessSSVRF()
{
	int8_t ret;
	ret=RF_TxProcess(TxBUF);
	if(ret==1) {
		ADC2TxBuffer();
		//printf ("RSSI:0x%x\n ",(uint8_t)AckData);
	}	
}
UINT16* limit10bit(int16_t ADC16)
{
	if(ADC16>1023)
		ADC16 = 1023;
	else if(ADC16<0)
		ADC16 = 0;
	
	return ADC16;
}
void ApplyJoyState(UINT8 ChSel)
{
	int8_t* JoyS;
	JoyS = GetJoyState();
	
	switch (ChSel)
	{
		case THR_CH:
			u16ADC[ChSel] = (UINT16)limit10bit(HAND_MODE(u16ADC[ChSel])+ JoyS[THR]);
		break;
		case ROLL_CH:
			u16ADC[ChSel] = (UINT16)limit10bit(HAND_MODE(u16ADC[ChSel]) + JoyS[ROLL]*2);
		break;
		case PITCH_CH:
			u16ADC[ChSel] = (UINT16)limit10bit(HAND_MODE(u16ADC[ChSel]) + JoyS[PITCH]*2);
		break;
		case YAW_CH:
			u16ADC[ChSel] = (UINT16)limit10bit(HAND_MODE(u16ADC[ChSel]) + JoyS[YAW]);
		break;
		case LB_CH:
			SW_ALT = GetSwitchValue(ALT_SWITCH);
		break;
		case RB_CH:
			SW_MOD = GetSwitchValue(MOD_SWITCH);
		break;
		default:
			break;
	}
}
void ProcessADC()
{
	UINT16 u16ADCL;
	UINT8 ChannelSel;
	
	if(ADCtimeUp) {
		ChannelSel = ((tickCounter>>1)%6);
		ADC_Channel_Sel(ChannelSel);
		Trigger_ADC_Convertion();
		u16ADCL = ADCCON0;
		u16ADCL = u16ADCL >> 6;
		u16ADC[ChannelSel] = ADCH;
		u16ADC[ChannelSel] = (u16ADC[ChannelSel] << 2 ) + u16ADCL;
		ADCtimeUp = 0;
		CheckBtn(u16ADC);
		ApplyJoyState(ChannelSel);
	}
}
void ProcessFlash()
{
	if(FLASHtimeUp) {
		if(CheckFlashUpdate()/*&&u16ADC[THR_CH]<THR_LOW_BOUND*/) {
			Erase_Page0();
			UpdateFlash();
			ClearFlashUpdate();
			DEBUG_PRINT("\nFlash update\n");
		}
		FLASHtimeUp = 0;
	}
}
void ProcessState()
{
	if(StatetimeUp) {
		UpdateState();
		StatetimeUp = 0;
	}
}
void main(void)
{
	int8_t i;
		
	AUXR1 |= SPI_Pin_Sel;
	InitialUART0_Timer1(9600); // 9600 Baud Rate @ 11.0592MHz
	printf ("\n2.4G Tx Demo Start.\n");
	TMOD&=0xf0;
	TMOD|=0x01;
	SPI_Initial();

	FlashInit();

	SSV7241_InitSPI();
	SSV7241_Init();
	SSV7241_PowerOn();
	Delay1ms(5);
	SSV7241_TX_Mode();

	ADC_Init();
	
	for(i=0;i<TxNUM;i++)
		TxBUF[i]=0;	

		tickCounter=0;
	PowerOnBeep();	
	do {
		ADCtimeUp=1;
		ProcessADC();
		tickCounter+=2;	
		Delay1ms(8);
	} while(tickCounter<=12);
	printf ("  ADC:%d,%d,%d,%d,%d,%d",SW_MOD,u16ADC[1],u16ADC[2],u16ADC[3],u16ADC[4],SW_ALT);
	ADC2TxBuffer();
	ADCtimeUp=0;

	while(1) {			
		ProcessSSVRF();		
		ProcessADC();
		ProcessFlash();
		ProcessState();
	}
}

//-----------------------------------------------------------------------------------------------------------
void Timer2_ISR(void) interrupt 5   // Vector @  0x2B
{
	TF2 = 0;
	if((tickCounter%2)==1)
		ADCtimeUp = 1;
	else
		SSVtimeUp = 1;
	
	if((tickCounter%750)==1)/* 3 sec */
		FLASHtimeUp = 1;
		
	if((tickCounter%25)==1)/* 100ms */
		StatetimeUp = 1;
	
	tickCounter++;	
}
//-----------------------------------------------------------------------------------------------------------
void SPI_Clock_Select(E_SPICLK_Sel Clock)
{
	switch(Clock) {
		case E_ClockDev16:
			clr_SPR0;
			clr_SPR1;
			break;
		case E_ClockDev32:
			set_SPR0;
			clr_SPR1;
			break;
		case E_ClockDev64:
			clr_SPR0;
			set_SPR1;
			break;
		case E_ClockDev128:
			set_SPR0;
			set_SPR1;
			break;
	}
}
//-----------------------------------------------------------------------------------------------------------
void SPI_Initial(void)
{
	
#if (SPI_Pin_Sel == 0x00)
	P3M1 |= SET_BIT4;                       // Enables Schmitt trigger inputs on Port 0.
	P3M1 |= SET_BIT5;                       // Enables Schmitt trigger inputs on Port 1.
#else
	P3M1 |= SET_BIT6;                       // Enables Schmitt trigger inputs on Port 2.
#endif
	set_DISMODF;                            // SS General purpose I/O ( No Mode Fault )
	clr_SSOE;

	clr_LSBFE;                              // MSB first

	clr_CPOL;                               // The SPI clock is low in idle mode
	clr_CPHA;                               // The data is sample on the first edge of SPI clock

	set_MSTR;                               // SPI in Master mode
	SPI_Clock_Select(E_ClockDev16);         // Select SPI clock
	set_SPIEN;                              // Enable SPI function
	clr_SPIF;
}

