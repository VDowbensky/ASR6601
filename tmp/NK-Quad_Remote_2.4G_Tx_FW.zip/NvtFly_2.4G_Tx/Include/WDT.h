#define set_WDTEN \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDTEN = 1;    \
    EA = EA_Save_bit;
#define set_WDCLR \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDCLR = 1;    \
    EA = EA_Save_bit;
#define set_WDTF  \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDTF = 1;     \
    EA = EA_Save_bit;
#define set_WIDPD \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    WIDPD = 1;    \
    EA = EA_Save_bit;
#define set_WDTRF \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDTRF = 1;    \
    EA = EA_Save_bit;
#define set_WPS2  \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    WPS2 = 1;     \
    EA = EA_Save_bit;
#define set_WPS1  \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    WPS1 = 1;     \
    EA = EA_Save_bit;
#define set_WPS0  \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    WPS0 = 1;     \
    EA = EA_Save_bit;
#define set_ewrst \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDCON1 |= SET_BIT0;\
    EA = EA_Save_bit;
//==============================
#define clr_WDTEN \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDTEN = 0;    \
    EA = EA_Save_bit;
#define clr_WDCLR \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDCLR = 0;    \
    EA = EA_Save_bit;
#define clr_WDTF  \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDTF = 0;     \
    EA = EA_Save_bit;
#define clr_WIDPD \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    WIDPD = 0;    \
    EA = EA_Save_bit;
#define clr_WDTRF \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDTRF = 0;    \
    EA = EA_Save_bit;
#define clr_WPS2  \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    WPS2 = 0;     \
    EA = EA_Save_bit;
#define clr_WPS1  \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    WPS1 = 0;     \
    EA = EA_Save_bit;
#define clr_WPS0  \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    WPS0 = 0;     \
    EA = EA_Save_bit;
#define clr_EWRST \
    EA_Save_bit = EA;      \
    EA = 0;       \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDCON1 &= CLR_BIT0;\
    EA = EA_Save_bit;