/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright(c) 2014 Nuvoton Technology Corp. All rights reserved.                                         */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

//***********************************************************************************************************
//  Nuvoton Technology  Corp.
//  Date: 23/Jan/2014
//  E-Mail: MicroC-8bit@nuvoton.com
//***********************************************************************************************************
#include <stdio.h>
#include "N79E81x.h"
#include "Typedef.h"
#include "Define.h"
#include "Common.h"
#include "Delay.h"

#define FW_Version_Major                    0x01
#define FW_Version_Minor                    0x00
#define FW_Version_Modifi                   0x02

#define Date_Y                              2014
#define Date_M                              1
#define Date_D                              23

//-----------------------------------------------------------------------------------------------------------
void Show_Version_Number_To_PC(void)
{
    printf ("\n");
    printf ("\n====================================================================");
    printf ("\n*  Copyright(c) 2014 Nuvoton Technology Corp. All rights reserved.  ");
    printf ("\n*  Sample Name     : Nuvoton N79E81x Series Sample Code.            ");
    printf ("\n*  Contact E-Mail: MicroC-8bit@nuvoton.com                          ");
    printf ("\n*  Sample Version  : %2d.%2d.%2d",(uint16_t)FW_Version_Major,(uint16_t)FW_Version_Minor,(uint16_t)FW_Version_Modifi);
    printf ("\n*  Finished Date : %2d.%2d.%2d",(uint16_t)Date_Y,(uint16_t)Date_M,(uint16_t)Date_D);
    printf ("\n====================================================================");
}