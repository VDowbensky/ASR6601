void Delay10us(UINT16 u16CNT);
void Delay1ms (UINT32 u32CNT);
void Delay1us(UINT16 u16CNT);
void Delay8msInit(void);
void WaitDelay(void);