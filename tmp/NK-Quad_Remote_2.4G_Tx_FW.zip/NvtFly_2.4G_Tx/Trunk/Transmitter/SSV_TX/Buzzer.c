/*============================================================================*
 * O     O          __                   ______  __                           *
 *  \   /      /\  / /_      _    __    / /___/ / /_     _                    *
 *   [+]      /  \/ / \\    //__ / /__ / /____ / / \\   //                    *
 *  /   \    / /\  /   \\__// --/ /---/ /----// /   \\_//                     *
 * O     O  /_/  \/     \__/    \_\/ /_/     /_/ ____/_/                      *
 *                                                                            *
 *                                                                            *
 * Multi-Rotor controller firmware for Nuvoton Cortex M4 series               *
 *                                                                            *
 * Written by K.H Hsu for Nuvoton Technology.                                 *
 *                                                                            *
 *============================================================================*
 */
#include "N79E81x.h"
#include "Typedef.h"
#define Time_parameter 2048
uint16_t Music_scale;
uint16_t Music_time=0;
uint8_t  Music_Flag=0;
uint8_t  Time_DO ;
uint8_t  Time_RE;
uint8_t  Time_MI;
void Beep(uint8_t DO, uint8_t RE, uint8_t ME,uint8_t TD ,uint8_t TR, uint8_t TM)
{
	Music_Flag = 0x00;
	Music_scale =0;
	Music_time = 0;
	if(DO == 1)
	{
		Time_DO = TD ;
    Music_Flag |= 0X01;
	}
  if(RE == 1)
	{
		Time_RE = TR ;
    Music_Flag |= 0X02;
	}
  if(ME == 1)
	{
		Time_MI = TM ;
    Music_Flag |= 0X04;
	}	
  
  ET1 = 1; //kevin
}
void PowerOnBeep() 
{ 
	Beep(0,1,1,0,2,2);
	while(Music_Flag !=0x00);
	Beep(0,1,1,0,2,2);
	while(Music_Flag !=0x00);
	Beep(1,1,1,2,2,2);
	while(Music_Flag !=0x00);
}
void SSVLinkBeep() 
{ 
	Beep(1,1,1,1,1,1);
	//while(Music_Flag !=0x00);
	//ET1 = 0;
}
/*
600   60  Hz
300   120 Hz
100   350 Hz
50    700 Hz
20    1.6 kHz
10    3.1 kHz
*/
void Timer1_ISR(void) interrupt 3   // Vector @  0x1B
{
	TF1 = 0;
	Music_scale++;
  Music_time++;
  if((Music_Flag &0X01)==0X01)
  {
	  if(Music_time<Time_parameter*Time_DO)
		{
			if(Music_scale<=7)
			{
				P07 = 0;
			}
			else if (Music_scale<=16)
			{
				P07 = 1;
			}
			else
			{
				Music_scale=0;
			}
		}
		else
		{
			Music_Flag &= 0XFE;
			Music_time=0;
			Music_scale=0;
			P07= 1;
		}
  }
	else if((Music_Flag &0X02)==0X02)
  {
	  if(Music_time<Time_parameter*Time_RE)
		{
			if(Music_scale<=8)
			{
				P07 = 0;
			}
			else if (Music_scale<=18)
			{
				P07 = 1;
			}
			else
			{
				Music_scale=0;
			}
		}
		else
		{
			Music_Flag &= 0XFD;
			Music_time=0;
			Music_scale=0;
			P07= 1;
		}
  }
  else if((Music_Flag &0X04)==0X04)
  {
	  if(Music_time<Time_parameter*Time_MI)
		{
			if(Music_scale<=4)
			{
				P07 = 0;
			}
			else if (Music_scale<=13)
			{
				P07 = 1;
			}
			else
			{
				Music_scale=0;
			}
		}
		else
		{
			Music_Flag &= 0XFB;
			Music_time=0;
			Music_scale=0;
			P07= 1;
		}
  }
	else
	{
		  ET1 = 0;
	}
}